﻿namespace WebApplication8.BussinessEntity
{
    public class UserViewModelBase
    {
        public string Name { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }

        public int Id { get; set; } 
       
    }
}