﻿using Microsoft.AspNetCore.Mvc;
using WebApplication8.BussinessEntity;
using WebApplication8.BussinessService;
using WebApplication8.BussinessService.Concreate;

namespace WebApplication8.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        public UserController()
        {
            _userService = new UserService();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(UserViewModel user)
        {
            var d= _userService.AddUserInfo(user);
            return RedirectToAction("Index");   

        }

    }
}
