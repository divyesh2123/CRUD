﻿using System;
using System.Collections.Generic;

namespace WebApplication5;

public partial class Poc
{
    public int? Id { get; set; }

    public string? Name { get; set; }
}
