﻿using WebApplication8.BussinessEntity;
using WebApplication8.Database;

namespace WebApplication8.Common
{
    public static class Helper
    {
        public static User ToDataModel(this UserViewModel userViewModel)
        {
            User user = new User();
            user.Address1 = userViewModel.Address1;
            user.Address2 = userViewModel.Address2;
            user.Name = userViewModel.Name;
            return user;

        }

        public static UserViewModel ToViewModelForRegistration(this User user)
        {
            UserViewModel d = new UserViewModel();
            d.Address1 = user.Address1;
            d.Address2 = user.Address2;
            d.Name = user.Name;
            d.Password = user.Password;
            return d;
        
        }

        public static UserViewModelBase ToViewModel(this User user)
        {
            UserViewModelBase userViewModelBase = new UserViewModelBase();  
            userViewModelBase.Address1 = user.Address1;
            userViewModelBase.Address2= user.Address2;
            userViewModelBase.Name = user.Name; 
            userViewModelBase.Id = user.Id;
            
            return userViewModelBase;

        }

        public static List<UserViewModelBase> ToViewModel(this List<User> user)
        {
            return user.Select(x => x.ToViewModel()).ToList();



        }



        }
}